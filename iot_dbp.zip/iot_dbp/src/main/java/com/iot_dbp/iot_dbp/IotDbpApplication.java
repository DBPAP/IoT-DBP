package com.iot_dbp.iot_dbp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IotDbpApplication {

	public static void main(String[] args) {
		SpringApplication.run(IotDbpApplication.class, args);
	}
}
