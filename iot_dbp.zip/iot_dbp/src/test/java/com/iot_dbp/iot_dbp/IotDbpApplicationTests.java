package com.iot_dbp.iot_dbp;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IotDbpApplicationTests {

	@Test
	public void contextLoads() {
	}

}
